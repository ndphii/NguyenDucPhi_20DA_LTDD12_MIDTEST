package com.example.lab2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detal)
    }
}