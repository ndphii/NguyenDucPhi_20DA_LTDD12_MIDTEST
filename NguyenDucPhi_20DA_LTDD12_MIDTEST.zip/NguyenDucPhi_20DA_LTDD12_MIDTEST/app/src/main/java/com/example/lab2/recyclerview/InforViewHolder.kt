package com.example.lab2.recyclerview

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.lab2.databinding.ItemMusicBinding

class InforViewHolder private constructor(
    private val binding: ItemMusicBinding
) : RecyclerView.ViewHolder(binding.root) {

    companion object {
        fun from(parent: ViewGroup): InforViewHolder {
            val binding = ItemMusicBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return InforViewHolder(binding)
        }
    }

    fun bind(info: info) {
        binding.info.text = info.name
        binding.singer.text = info.singer
    }
}
