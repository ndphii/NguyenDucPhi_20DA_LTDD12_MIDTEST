package com.example.lab2.recyclerview

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class InforAdapter(
    private val listInfos: List<info>
) : RecyclerView.Adapter<InforViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = InforViewHolder.from(parent)

    override fun onBindViewHolder(holder: InforViewHolder, position: Int) {
        holder.bind(listInfos[position])
    }

    override fun getItemCount() = listInfos.size
}
