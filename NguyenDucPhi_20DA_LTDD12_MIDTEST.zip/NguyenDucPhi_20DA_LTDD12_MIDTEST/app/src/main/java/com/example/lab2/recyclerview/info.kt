package com.example.lab2.recyclerview

data class info(
    val name: String,
    val singer: String
)
